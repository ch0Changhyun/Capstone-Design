<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>회원 정보 찾기</title>
</head>
<body>
  <h1>회원 정보 페이지</h1>
    <form method ="post" action ="forget_IdPw_fun.php">
        <p>이름 : <input type = "text" name = "username" placeholder= "username"></p>
        <p>전화번호 : <input type="text" name="userphone" placeholder="Phone Ex) 01012345678"></p>
        <p><input type = submit value = "찾기"></p>
    </form>
</body>
